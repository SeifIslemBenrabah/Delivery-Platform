package com.example.demo.Entity;

public enum Role {
    CLIENT,
    LIVREUR,
    COMMERCANT
}