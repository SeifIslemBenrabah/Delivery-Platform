package com.example.demo.Entity;

import java.io.Serializable;

public class Address implements Serializable {

    public Number longitude;
    public Number latitude;
    
}
